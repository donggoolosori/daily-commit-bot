# daily-commit-bot
Check daily commit and alarm with telegram bot
